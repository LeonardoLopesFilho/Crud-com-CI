<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parceiros</title>
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
<div class="py-2	">
      <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
        Visualizar Cadastro
      </h2>
    </div>
<div class="py-5 w-full">
<div class="lg:flex items-center justify-center w-full">
    <div class="lg:w-4/12 lg:mr-7 lg:mb-0 mb-7 bg-white p-6 shadow rounded">
        <div class="flex items-center border-b border-gray-200 pb-6">
        <img src="https://img.icons8.com/cotton/64/000000/conference-call.png"alt="" class="w-12 h-12 rounded-full" />
            <div class="flex items-start justify-between w-full">
                <div class="pl-3 w-full">
                    <p class="text-xl font-medium leading-5 text-gray-800"><?php echo $parceiros->nomeponto ?></p>
                    <p class="text-sm leading-normal pt-2 text-gray-500">ID: <?php echo $parceiros->id ?></p>
                    <div class="flex py-2">
                      <div class="py-2 px-4 text-xs leading-3 text-indigo-700 rounded-full bg-indigo-100"><?php echo $parceiros->unidade ?></div>
                    </div>
                </div>
                <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.5001 4.66667H17.5001C18.1189 4.66667 18.7124 4.9125 19.15 5.35009C19.5876 5.78767 19.8334 6.38117 19.8334 7V23.3333L14.0001 19.8333L8.16675 23.3333V7C8.16675 6.38117 8.41258 5.78767 8.85017 5.35009C9.28775 4.9125 9.88124 4.66667 10.5001 4.66667Z" stroke="#2C3E50" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
        </div>
        <div class="">
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">Site do Ponto: <?php echo $parceiros->siteponto ?></p>
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">CNPJ ou CPF Do Ponto: <?php echo $parceiros->cpfoucnpj ?></p>
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">Endereço do Ponto: <?php echo $parceiros->endereco ?></p>
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">Numero do Ponto: <?php echo $parceiros->numero ?></p>
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">Telefone 1 do Ponto: <?php echo $parceiros->telefone1 ?></p>
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">Telefone 2 do Ponto: <?php echo $parceiros->telefone2 ?></p>
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">Dono do Ponto: <?php echo $parceiros->nomedono ?></p>
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">Nascimento do Dono: <?php echo $parceiros->nascimentodono ?></p>
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">CPF do Dono: <?php echo $parceiros->cpfdono ?></p>
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">Banco Cadastrado: <?php echo $parceiros->nomebanco ?></p>
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">Agencia e Conta: <?php echo $parceiros->agenciaeconta ?></p>
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">Pix Cadastrado: <?php echo $parceiros->pix ?></p>
            <p class="text-sm leading-5 py-1 font-semibold text-gray-600">Email Cadastrado: <?php echo $parceiros->email ?></p>
        </div>
        <a class="btn text-center " href="/parceiros" role="button">
        <button class="bg-blue-500 hover:bg-blue-400 text-white font-bold py-2 px-4 border-b-4 border-blue-700 hover:border-blue-500 rounded">
          Voltar
        </button>
      </a>
    </div>
    
</body>
</html>