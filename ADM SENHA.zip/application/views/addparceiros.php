<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parceiros</title>
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body font-mono bg-gray-400>
<div class="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
  <div class="max-w-md w-full space-y-8">
    <div>
      <img class="mx-auto h-12 w-auto" src="https://tailwindui.com/img/logos/workflow-mark-indigo-600.svg" alt="Workflow">
      <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
        Cadastrar Novo Parceiro
      </h2>
    </div>
    <form class="mt-8 space-y-6" action="/parceiros/salvar" name="form_add" method="POST">
      <input type="hidden" name="remember" value="true">
      <div class="rounded-md shadow-sm -space-y-px">
        <div>
          <label for="ID" class="sr-only">ID</label>
          <input id="id" name="id" type="number" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="ID">
        </div>
        <div>
          <label for="nome" class="sr-only">Nome do Ponto de Atendimento</label>
          <input id="nome" name="nome" type="Text" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="Nome Do ponto">
        </div>
        <div>
          <label for="site" class="sr-only">Web Site do Ponto</label>
          <input id="site" name="site" type="Text" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="Site do ponto">
        </div>
        <div>
          <label for="cpfoucnpj" class="sr-only">CPF ou CNPJ</label>
          <input id="cpfoucnpj" name="cpfoucnpj" type="number" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="CPF OU CNPJ">
        </div>
        <div>
          <label for="unidade" class="sr-only">Unidade</label>
          <input id="unidade" name="unidade" type="Text" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="Unidade">
        </div>
        <div>
          <label for="endereco" class="sr-only">Endereço da unidade</label>
          <input id="endereco" name="endereco" type="Text" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="Endereço da unidade">
        </div>
        <div>
          <label for="telefone1" class="sr-only">Telefone 1</label>
          <input id="telefone1" name="telefone1" type="number" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="Tel 1">
        </div>
        <div>
          <label for="telefone2" class="sr-only">Telefone 2</label>
          <input id="telefone2" name="telefone2" type="number" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="Tel 2 ">
        </div>
        <div>
          <label for="nomedono" class="sr-only">Nome do Proprietário</label>
          <input id="nomedono" name="nomedono" type="Text" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="Nome do Proprietario">
        </div>
        <div>
          <label for="nascimentodono" class="sr-only">Data de nascimento do dono</label>
          <input id="nascimentodono" name="nascimentodono" type="date" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="Data de nascimento">
        </div>
        <div>
          <label for="cpfdono" class="sr-only">CPF do Responsavel</label>
          <input id="cpfdono" name="cpfdono" type="number" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="CPF Responsavel">
        </div>
        <div>
          <label for="celulardono" class="sr-only">Celular do Responsavel</label>
          <input id="celulardono" name="celulardono" type="number" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="Celular do Responsavel">
        </div>
        <div>
          <label for="nomebanco" class="sr-only">Nome do banco</label>
          <input id="nomebanco" name="nomebanco" type="Text" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="Nome do Banco">
        </div>
        <div>
          <label for="agenciaeconta" class="sr-only">Agencia e conta</label>
          <input id="agenciaeconta" name="agenciaeconta" type="number" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="Agencia e conta">
        </div>
        <div>
          <label for="pix" class="sr-only">Pix</label>
          <input id="pix" name="pix" type="Text" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="Pix">
        </div>
        <div>
          <label for="email" class="sr-only">E-mail</label>
          <input id="email" name="email" type="Text" autocomplete="off" required class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" placeholder="E-MAIL">
        </div>

      </div>
      <div>
        <button type="submit" class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
          Cadastrar
        </button>
      </div>
    </form>
  </div>
</div>
</body>
</html>