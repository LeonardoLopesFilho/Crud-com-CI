<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parceiros</title>
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
    <h1 class="text-center pt-6 font-bold">Lista de PA e AGR</h1>
    
<div class="md:px-32 py-8 w-full">
      <a class="btn text-center pt-4 pb-4" href="parceiros/add" role="button">
      <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
        Adicionar novo Cadastro
      </button>
      </a>
  <div class="shadow overflow-hidden rounded border-b border-gray-200">
    <table class="min-w-full bg-white">
      <thead class="bg-gray-800 text-white">
        <tr>
          <th class="w-1/3 text-left py-3 px-4 uppercase font-semibold text-sm">ID</th>
          <th class="w-1/3 text-left py-3 px-4 uppercase font-semibold text-sm">Nome</th>
          <th class="w-1/3 text-left py-3 px-4 uppercase font-semibold text-sm">Ações</th>  
        </tr>
      </thead>
    <tbody class="text-gray-700">
        <?php $contador = 0; foreach ($parceiros as $parceiro){?>
      <tr>
        <td class="w-1/3 text-left py-3 px-4 font-bold"><?php echo $parceiro->id ?></td>
        <td class="w-1/3 text-left py-3 px-4 font-bold" ><?php echo $parceiro->nome ?></td>
        <td class="pt-4 pb-4"> 
            <a class="btn btn-primary" href="#" role="button">
                <button class="bg-blue-500 hover:bg-blue-400 text-white font-bold py-2 px-4 border-b-4 border-blue-700 hover:border-blue-500 rounded">
                    Editar
                </button>
            </a>
            <a class="btn btn-danger" href="#" role="button">
                <button class="bg-red-500 hover:bg-red-400 text-white font-bold py-2 px-4 border-b-4 border-red-700 hover:border-red-500 rounded">
                    Excluir
                </button>
            </a>
            <a class="btn btn-danger" href="#" role="button">
                <button class="bg-green-500 hover:bg-green-400 text-white font-bold py-2 px-4 border-b-4 border-green-700 hover:border-green-500 rounded">
                    Visualizar
                </button>
            </a>      
        </td>
      </tr>
      <?php $contador++; } ?>
    </tbody>
    </table>
 </div>
    <div class="row">
        <div class="col-md-12 uppercase font-bold">
            Total de Registros: <?php echo $contador?>
        </div>        
</div>
</body>
</html>