<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parceiros</title>
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
  
    <h1 class="text-center pt-6 font-bold">Lista de PA e AGR</h1>
  
    <div class="md:px-32 flex  pt-4">
        <!-- INPUT DE PESQUISA!-->
        <div class="relative text-gray-600">
       
        <form action="/parceiros/pesquisar" method="POST" class="">
             <input type="text" autocomplete="off" id="pesquisa" name="pesquisa" placeholder="Pesquisar" class=" bg-white h-10 border-2 border-blue-500 px-5 pr-10 rounded-md text-sm focus:outline-none">
            <button type="submit" class="absolute right-0 top-0 mt-3 mr-4">
              <svg class="h-4 w-4 fill-current" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" viewBox="0 0 56.966 56.966" style="enable-background:new 0 0 56.966 56.966;" xml:space="preserve" width="512px" height="512px">
                <path d="M55.146,51.887L41.588,37.786c3.486-4.144,5.396-9.358,5.396-14.786c0-12.682-10.318-23-23-23s-23,10.318-23,23  s10.318,23,23,23c4.761,0,9.298-1.436,13.177-4.162l13.661,14.208c0.571,0.593,1.339,0.92,2.162,0.92  c0.779,0,1.518-0.297,2.079-0.837C56.255,54.982,56.293,53.08,55.146,51.887z M23.984,6c9.374,0,17,7.626,17,17s-7.626,17-17,17  s-17-7.626-17-17S14.61,6,23.984,6z"/>
              </svg>
            </button>
      
          </form>
        </div>
      </div>
    <div class="md:px-32 flex  pt-4">
      <!-- bOTÃO DE criar novo registro !-->
      <a class="btn text-center " href="parceiros/add" role="button">
        <button class="bg-blue-500 hover:bg-blue-400 text-white font-bold py-2 px-4 border-b-4 border-blue-700 hover:border-blue-500 rounded">
          Adicionar novo Cadastro
        </button>
      </a>
      <div class="px-1">
        <!-- bOTÃO DE atualiza a lista!-->
        <a class="btn text-center " href="https://bricertificadodigital.com.br/" role="button">
          <button class="bg-blue-500 hover:bg-blue-400 text-white font-bold py-2 px-4 border-b-4 border-blue-700 hover:border-blue-500 rounded">
            Recarregar Lista
          </button>
        </a>
      </div>
    </div>
    <div class="px-32	 pt-4		">  
        <div class="h-48 flex flex-wrap content-start">  
          <table class="text-left w-full">
          <thead class="bg-black flex text-white w-full">
            <tr class="flex w-full mb-4">
              <th class="p-4 w-1/4">ID</th>
              <th class="p-4 w-1/4">Nome do Ponto</th>
              <th class="p-4 w-1/4">Endereço</th>
              <th class="p-4 w-1/4">Telefone 1</th>
              <th class="p-4 w-1/4">Nome do dono </th>
              <th class="p-4 w-1/4">Ações</th>
            </tr>
          </thead>
          
          <tbody class="bg-grey-light flex flex-col items-center py-3 overflow-y-scroll border-2 border-black-500 " style="height: 50vh;">
          <?php $contador = 0; foreach ($parceiros as $parceiro){?>
            <tr class="flex w-full">
              <td class="p-4 w-1/4"><?php echo $parceiro->id ?></td>
              <td class="p-4 w-1/4"><?php echo $parceiro->nomeponto ?></td>
              <td class="p-4 w-1/4"><?php echo $parceiro->endereco ?></td>
              <td class="p-4 w-1/4"><?php echo $parceiro->telefone1 ?></td>
              <td class="p-4 w-1/4"><?php echo $parceiro->nomedono ?></td>
              <td class="p-4 w-1/4">
              <a class="btn btn-primary" href="parceiros/editar/<?=$parceiro->id;?>" role="button">
                      <button class="bg-blue-500 hover:bg-blue-400 text-white font-bold py-2 px-4 border-b-4 border-blue-700 hover:border-blue-500 rounded">
                        <img src="https://img.icons8.com/android/15/000000/edit.png"/>
                      </button>
                  </a>
                  <a class="btn btn-danger" href="parceiros/apagar/<?=$parceiro->id;?>" role="button">
                      <button class="bg-red-500 hover:bg-red-400 text-white font-bold py-2 px-4 border-b-4 border-red-700 hover:border-red-500 rounded">
                        <img src="https://img.icons8.com/ios-glyphs/15/000000/delete-sign.png"/>
                      </button>
                  </a>
                  <a class="btn btn-danger" href="parceiros/ver/<?=$parceiro->id;?>" role="button">
                      <button class="bg-green-500 hover:bg-green-400 text-white font-bold py-2 px-4 border-b-4 border-green-700 hover:border-green-500 rounded">
                        <img src="https://img.icons8.com/ios-filled/15/000000/view-file.png"/>
                      </button>
                  </a> 
              </td>
            </tr>
            <?php $contador++; } ?>
          </tbody>  
          </table>
          <div class="row">
                <div class="col-md-12 uppercase font-bold">
                    Total de Registros: <?php echo $contador?>
                </div>        
              </div>
        </div> 
      </div>   
            

    </body>
   </html>    
  <!--
<div class="md:px-32 py-2 pt-2 pb-2 w-full">
  <div class="shadow overflow-hidden rounded border-b border-gray-200">
    <table class="min-w-min bg-white">
      <thead class="bg-gray-800 text-white">
        <tr>
          <th class="w-1/3 text-left py-3 px-2 uppercase font-semibold text-sm">ID</th>
          <th class="w-1/3 text-left py-3 px-4 uppercase font-semibold text-sm">Nome Ponto</th>
          <th class="w-1/3 text-left py-3 px-4 uppercase font-semibold text-sm">endereço</th>
          <th class="w-1/3 text-left py-3 px-4 uppercase font-semibold text-sm">Telefone 1</th>
          <th class="w-1/3 text-left py-3 px-4 uppercase font-semibold text-sm">Nome do Dono</th>
          <th class="w-1/3 text-left py-3 px-4 uppercase font-semibold text-sm">Ações</th>  
        </tr>
      </thead>
    <tbody class="text-gray-700">
        <?php $contador = 0; foreach ($parceiros as $parceiro){?>
      <tr>
        <td class="w-1/3 text-left py-3 px-2 font-bold"><?php echo $parceiro->id ?></td>
        <td class="w-1/3 text-left py-3 px-4 font-bold" ><?php echo $parceiro->nomeponto ?></td>
        <td class="w-1/3 text-left py-3 px-4 font-bold"><?php echo $parceiro->endereco ?></td>
        <td class="w-1/3 text-left py-3 px-4 font-bold" ><?php echo $parceiro->telefone1 ?></td>
        <td class="w-1/3 text-left py-3 px-4 font-bold" ><?php echo $parceiro->nomedono ?></td>
        <td class="pt-4 pb-4"> 
            <a class="btn btn-primary" href="parceiros/editar/<?=$parceiro->id;?>" role="button">
                <button class="bg-blue-500 hover:bg-blue-400 text-white font-bold py-2 px-4 border-b-4 border-blue-700 hover:border-blue-500 rounded">
                  <img src="https://img.icons8.com/android/15/000000/edit.png"/>
                </button>
            </a>
            <a class="btn btn-danger" href="parceiros/apagar/<?=$parceiro->id;?>" role="button">
                <button class="bg-red-500 hover:bg-red-400 text-white font-bold py-2 px-4 border-b-4 border-red-700 hover:border-red-500 rounded">
                  <img src="https://img.icons8.com/ios-glyphs/15/000000/delete-sign.png"/>
                </button>
            </a>
            <a class="btn btn-danger" href="" role="button">
                <button class="bg-green-500 hover:bg-green-400 text-white font-bold py-2 px-4 border-b-4 border-green-700 hover:border-green-500 rounded">
                  <img src="https://img.icons8.com/ios-filled/15/000000/view-file.png"/>
                </button>
            </a>        
        </td>
      </tr>
      <?php $contador++; } ?>
    </tbody>
    </table>
    
 </div>
    <div class="row">
        <div class="col-md-12 uppercase font-bold">
            Total de Registros: <?php echo $contador?>
        </div>        
</div>
</body>
</html>