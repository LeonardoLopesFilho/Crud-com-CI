<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Parceiros_model extends CI_model 
{
    public function getParceiros()
    {
        $query = $this->db->get('tab_pa');
        return $query->result();
    }

    public function addparceiros($dados){
        if($dados!=NULL):
            $this->db->insert('tab_pa',$dados);
        endif;
    }

    public function getParceiroByID($id){
        if($id!=NULL):
            $this->db->where('id',$id);
            $this->db->limit(1);
            $query = $this->db->get("tab_pa");
            return $query->row();
        endif;
    }

    public function editarparceiros($dados,$id){
        //verifica se foi passado dados e id
        if($dados!=NULL && $id!=NULL):
            //se foi passado ele vai atualizar
            $this->db->update('tab_pa',$dados, array('id'=>$id));
        endif;
    }

    //Apaga um produto na tabela produtos

    public function apagarparceiro($id){
        //Verificamos se foi passado um id
        if($id!=NULL):
            //Executa a função Delete no banco
            $this->db->delete('tab_pa',array('id'=>$id));
        endif;    
    }

    //Fazer a pesquisa no banco
    public function getParceiro($nome){
        if($nome!=NULL):
            $this->db->where('nome',$nome);
            //$this->db->limit(1);
            $query = $this->db->get("tab_pa");
            return $query->result();
        endif;
    }


}