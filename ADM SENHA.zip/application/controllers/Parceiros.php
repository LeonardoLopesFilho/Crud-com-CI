<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parceiros extends CI_Controller {


	//Listagem de Parceiros
	public function index()
	{	
		$this->load->model('parceiros_model','parceiros');

		$data['parceiros'] = $this->parceiros->getParceiros();

		$this->load->view('listarParceiros',$data);
	}

	//carrega a tela para adicionar um Parceiro
	public function add()
	{
		$this->load->model('parceiros_model','parceiros');

		$this->load->view('addparceiros');
	}

	//função para salvar um parceiro no banco
	public function salvar()
	{	
		//verifica se tem algo no campo nome
		if($this->input->post('nome') == NULL){
			echo 'O campo nome do parceiro é obrigatorio';
			echo '<a href="/parceiros/add" title="Voltar"Voltar</a>';
		} else {

			$this->load->model('parceiros_model','parceiros');

			//Pega os dados do post e coloca no array
			$dados['id'] = $this->input->post('id');
			$dados['nome'] = $this->input->post('nome');

			//executa a função do model adicionar
			$this->parceiros->addparceiros($dados);

			header("Location: https://bricertificadodigital.com.br/");

		}
	}

	public function editar($id=NULL){

		//verifica se foi passado um ID
		if ($id == NULL) {
			
			header("Location: https://bricertificadodigital.com.br/");
		}

		$this->load->model('parceiros_model','parceiros');

		$query = $this->parceiros->getParceiroByID($id);

		if ($query == NULL) {
			header("Location: https://bricertificadodigital.com.br/");
		}

		$dados['parceiros'] = $query;

		$this->load->view('editarparceiros',$dados);

	}
}
