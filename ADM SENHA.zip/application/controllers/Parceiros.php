<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parceiros extends CI_Controller {


	//Listagem de Parceiros
	public function index()
	{	
		$this->load->model('parceiros_model','parceiros');

		$data['parceiros'] = $this->parceiros->getParceiros();

		$this->load->view('listarParceiros',$data);
	}

	//carrega a tela para adicionar um Parceiro
	public function add()
	{
		$this->load->model('parceiros_model','parceiros');

		$this->load->view('addparceiros');
	}

	//função para salvar um parceiro no banco
	public function salvar()
	{	
		//verifica se tem algo no campo nome
		if($this->input->post('nome') == NULL){
			echo 'O campo nome do parceiro é obrigatorio';
			echo '<a href="/parceiros/add" title="Voltar"Voltar</a>';
		} else {

			$this->load->model('parceiros_model','parceiros');

			//Pega os dados do post e coloca no array
			$dados['id'] = $this->input->post('id');
			$dados['nome'] = $this->input->post('nome');

			//executa a função do model adicionar
			$this->parceiros->addparceiros($dados);

			header("Location: https://bricertificadodigital.com.br/");

		}
	}

	public function editar($id){

		//verifica se foi passado um ID
		if ($id == NULL) {
			
			header("Location: https://bricertificadodigital.com.br/");
		}

		$this->load->model('parceiros_model','parceiros');

		$query = $this->parceiros->getParceiroByID($id);

		if ($query == NULL) {
			header("Location: https://bricertificadodigital.com.br/");
		}

		$dados['parceiros'] = $query;

		$this->load->view('editarparceiros',$dados);

	}

	public function atualizar()
	{	
		
		$this->load->model('parceiros_model','parceiros');

		$id = $this->input->post('id');

		//Pega os dados do post e coloca no array
		$dados['id'] = $this->input->post('id');
		$dados['nome'] = $this->input->post('nome');

		//executa a função do model adicionar

		$this->parceiros->editarparceiros($dados,$id);

		header("Location: https://bricertificadodigital.com.br/");

		
	}

	public function apagar($id){

		//Verifica se foi passado um id
		if($id == NULL){
			header("Location: https://bricertificadodigital.com.br/");
		}

		//Carrega a model
		$this->load->model('parceiros_model','parceiros');

		//Faz a consulta no banco para verificar se existe o id
		$query = $this->parceiros->getParceiroByID($id);

		//verifica se foi encontrado um registro no banco
		if($query != NULL){

			//echo "<pre>";
			//print_r($query->id);
			//echo "</pre>";
			
			$idb = $query->id;
			//Executa a função apagar parceiros na parceiros_model
			$this->parceiros->apagarparceiro($idb);
			header("Location: https://bricertificadodigital.com.br/");

		}else{
			//Se nao encontrou nada volta para a Listagem
			header("Location: https://bricertificadodigital.com.br/");
		}

		
	}

	public function pesquisar()
	{	
		$this->load->model('parceiros_model','parceiros');

		$pesquisa = $this->input->post('pesquisa');
		
		$data['parceiros'] = $this->parceiros->getParceiro($pesquisa);

		$this->load->view('listarParceiros',$data);
	}

}	

