<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parceiros extends CI_Controller {


	//Listagem de Parceiros
	public function index()
	{	
		$this->load->model('parceiros_model','parceiros');

		$data['parceiros'] = $this->parceiros->getParceiros();

		$this->load->view('listarParceiros',$data);
	}

	//carrega a tela para adicionar um Parceiro
	public function add()
	{
		$this->load->model('parceiros_model','parceiros');

		$this->load->view('addparceiros');
	}

	public function ver($id)
	{
		
		//verifica se foi passado um ID
		if ($id == NULL) {
			
			header("Location: https://bricertificadodigital.com.br/");
		}

		$this->load->model('parceiros_model','parceiros');

		$query = $this->parceiros->getParceiroByID($id);

		if ($query == NULL) {
			header("Location: https://bricertificadodigital.com.br/");
		}

		$dados['parceiros'] = $query;

		$this->load->view('testeforms',$dados);
	}

	//função para salvar um parceiro no banco
	public function salvar()
	{	
		//verifica se tem algo no campo nome
		if($this->input->post('nome') == NULL){
			echo 'O campo nome do parceiro é obrigatorio';
			echo '<a href="/parceiros/add" title="Voltar"Voltar</a>';
		} else {

			$this->load->model('parceiros_model','parceiros');

			//Pega os dados do post e coloca no array
			$dados['id'] = $this->input->post('id');
			$dados['nomeponto'] = $this->input->post('nome');
			$dados['siteponto'] = $this->input->post('site');
			$dados['cpfoucnpj'] = $this->input->post('cpfoucnpj');
			$dados['unidade'] = $this->input->post('unidade');
			$dados['endereco'] = $this->input->post('endereco');
			$dados['numero'] = $this->input->post('numero');
			$dados['telefone1'] = $this->input->post('telefone1');
			$dados['telefone2'] = $this->input->post('telefone2');
			$dados['nomedono'] = $this->input->post('nomedono');
			$dados['nascimentodono'] = $this->input->post('nascimentodono');
			$dados['cpfdono'] = $this->input->post('cpfdono');
			$dados['celulardono'] = $this->input->post('celulardono');
			$dados['nomebanco'] = $this->input->post('nomebanco');
			$dados['agenciaeconta'] = $this->input->post('agenciaeconta');
			$dados['pix'] = $this->input->post('pix');
			$dados['email'] = $this->input->post('email');

			//echo '<pre>';
			//print_r($dados);
			//echo '</pre>';


			//executa a função do model adicionar
			$this->parceiros->addparceiros($dados);

			header("Location: https://bricertificadodigital.com.br/");

		}
	}

	public function editar($id){

		//verifica se foi passado um ID
		if ($id == NULL) {
			
			header("Location: https://bricertificadodigital.com.br/");
		}

		$this->load->model('parceiros_model','parceiros');

		$query = $this->parceiros->getParceiroByID($id);

		if ($query == NULL) {
			header("Location: https://bricertificadodigital.com.br/");
		}

		$dados['parceiros'] = $query;

		$this->load->view('editarparceiros',$dados);

	}

	public function atualizar()
	{	
		
		$this->load->model('parceiros_model','parceiros');

		$id = $this->input->post('id');

		//Pega os dados do post e coloca no array
		$dados['id'] = $this->input->post('id');
		$dados['nomeponto'] = $this->input->post('nome');
		$dados['siteponto'] = $this->input->post('site');
		$dados['cpfoucnpj'] = $this->input->post('cpfoucnpj');
		$dados['unidade'] = $this->input->post('unidade');
		$dados['endereco'] = $this->input->post('endereco');
		$dados['numero'] = $this->input->post('numero');
		$dados['telefone1'] = $this->input->post('telefone1');
		$dados['telefone2'] = $this->input->post('telefone2');
		$dados['nomedono'] = $this->input->post('nomedono');
		$dados['nascimentodono'] = $this->input->post('nascimentodono');
		$dados['cpfdono'] = $this->input->post('cpfdono');
		$dados['celulardono'] = $this->input->post('celulardono');
		$dados['nomebanco'] = $this->input->post('nomebanco');
		$dados['agenciaeconta'] = $this->input->post('agenciaeconta');
		$dados['pix'] = $this->input->post('pix');
		$dados['email'] = $this->input->post('email');

		//executa a função do model adicionar

		//echo '<pre>';
		//print_r($dados);
		//echo '</pre>';

		$this->parceiros->editarparceiros($dados,$id);

		header("Location: https://bricertificadodigital.com.br/");

		
	}

	public function apagar($id){

		//Verifica se foi passado um id
		if($id == NULL){
			header("Location: https://bricertificadodigital.com.br/");
		}

		//Carrega a model
		$this->load->model('parceiros_model','parceiros');

		//Faz a consulta no banco para verificar se existe o id
		$query = $this->parceiros->getParceiroByID($id);

		//verifica se foi encontrado um registro no banco
		if($query != NULL){

			//echo "<pre>";
			//print_r($query->id);
			//echo "</pre>";
			
			$idb = $query->id;
			//Executa a função apagar parceiros na parceiros_model
			$this->parceiros->apagarparceiro($idb);
			header("Location: https://bricertificadodigital.com.br/");

		}else{
			//Se nao encontrou nada volta para a Listagem
			header("Location: https://bricertificadodigital.com.br/");
		}

		
	}

	public function pesquisar()
	{	
		$this->load->model('parceiros_model','parceiros');

		$nomedono = $this->input->post('pesquisa');
		
		
		$data['parceiros'] = $this->parceiros->getParceiro($nomedono);

		//echo '<pre>';
		//print_r($data['parceiros']);
		//echo '</pre>';

		$this->load->view('listarParceiros',$data);
	}

	public function terere()
	{
		$this->load->model('parceiros_model','parceiros');

		$this->load->view('testeforms');
	}
}	

